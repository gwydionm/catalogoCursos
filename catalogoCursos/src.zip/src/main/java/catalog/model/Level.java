package catalog.model;

public enum Level {
	BASIC, INTERMEDIATE, ADVANCED
}