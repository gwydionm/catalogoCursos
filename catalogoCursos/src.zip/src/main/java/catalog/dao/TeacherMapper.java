package catalog.dao;

import java.util.List;

import catalog.model.Teacher;

public interface TeacherMapper {

	List<Teacher> selectAll();
	
}
